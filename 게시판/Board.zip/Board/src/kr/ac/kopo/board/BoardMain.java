package kr.ac.kopo.board;

import kr.ac.kopo.board.ui.BoardUI;

public class BoardMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BoardUI ui = new BoardUI();
		try {
			ui.execute();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}