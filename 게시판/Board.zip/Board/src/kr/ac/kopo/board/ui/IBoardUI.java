package kr.ac.kopo.board.ui;

public interface IBoardUI {

	void execute() throws Exception; // 키보드 입력 시 예외가 발생할 수 있으니 예외를 던져줌
}