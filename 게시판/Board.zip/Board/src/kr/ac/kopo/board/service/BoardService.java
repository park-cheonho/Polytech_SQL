package kr.ac.kopo.board.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import kr.ac.kopo.board.dao.BoardDAO;
import kr.ac.kopo.board.vo.BoardVO;

/* 
 * 	 --->		--->
 * UI 	 SERVICE	DAO
 * 	 <---	    <---

 */
public class BoardService {
	private BoardDAO boardDAO;
	
	public BoardService() {
		boardDAO = new BoardDAO();
	}
	public void insertBoard(BoardVO newBoard) {
		// 게시판 번호 setting
		int no = BoardSequence.getBoardSequence();
		newBoard.setNo(no);
		
		// 등록일(현재시간) setting
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String now = sdf.format(new Date());
		
		newBoard.setRegDate(now);
		System.out.println("SimpleDataFormat : "+newBoard );
		
		boardDAO.insertBoard(newBoard);
		// uservo를 ui에서 입력받고 service에 넘겨서 번호랑 date입력하고 userdao에서 리스트에 저장
	}
	public List<BoardVO> selectAllBoard() {
		// TODO Auto-generated method stub
		List<BoardVO> list = boardDAO.selectAllBoard();
		return list;
	}
	public BoardVO selectOneBoard(int no) {
		// TODO Auto-generated method stub
		BoardVO board = boardDAO.selectOneBoard(no);
		return board;
	}
	public void modifyBoard(BoardVO board) {
		// TODO Auto-generated method stub
		
		boardDAO.modifyBoard(board);
	}
	
	public void deleteBoardByNo(int no) {
		boardDAO.deleteBoardByNo(no);
	}
}