package kr.ac.kopo.board.ui;

import java.util.ArrayList;
import java.util.List;

import kr.ac.kopo.board.vo.BoardVO;

public class SelectAllUI extends BaseUI{

	@Override
	public void execute() throws Exception {
		// TODO Auto-generated method stub
		
		////////////////////////////////////////////////////
		// 메모리 or file or db에서 전체 게시물을 조회하는 서비스
		// List<BoardVO> list = xxx();
		List<BoardVO> list = boardService.selectAllBoard();
		////////////////////////////////////////////////////
		
		
		System.out.println("-----------------------------------------");
		if(list.isEmpty()) {
			System.out.println("\t등록된 게시물이 없습니다");
		}
		else {
			System.out.println("번호\t제목\t작성자\t등록일");
			for(BoardVO board : list) {
				System.out.println(board.getNo()+"\t"+board.getTitle()+"\t"+board.getWriter()+
						"\t"+board.getRegDate()
						);
				
			}
		}
		System.out.println("-----------------------------------------");
	}
}