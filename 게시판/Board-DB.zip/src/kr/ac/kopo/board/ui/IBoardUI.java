package kr.ac.kopo.board.ui;

public interface IBoardUI {

	void execute() throws Exception;
}
